 
import discovery from "./images/discovery.png";
import newTech from './images/testingnewtech.png'
import support from './images/support.png'
import seo from './images/seo.png'
import security from './images/security.png'
import meetingdeadlinescolored from './images/meetingdeadlinescolored.png'

 const services=[
    {
        card_title:"Discovery",
        card_img:discovery,
        card_text:"Discover new Things in minimum time"
    
    },
    {
        card_title:"New Technology",
        card_img:newTech,
        card_text:"enthusiastic to grab new technologies "
    
    },
    {
        card_title:"support",
        card_img:support,
        card_text:"Always ready for you!!!!"
    
    },
    {
        card_title:"Security",
        card_img:security,
        card_text:"One of the best security softwares in india"
    
    },
    {
        card_title:"SEO ",
        card_img:seo,
        card_text:"We can do Search engine optimization for  you"
    
    },
    {
        card_title:"Regular updates",
        card_img:meetingdeadlinescolored,
        card_text:"We provide Regular Updates to our customers"
    
    },
  
  
    
 ];
 export default services;